# bash-backup
Some backup scripts on bash
